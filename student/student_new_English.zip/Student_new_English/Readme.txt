User manual of student system
---------------------------------------------------------------------
The student roster is saved in classdata\name.dat
Format:one name per line.
The subject name is saved in classdata\sub.dat.
The number of students is saved in classdata\num.dat.
---------------------------------------------------------------------
Warning:The test name should not contain spaces when you saved files.
You can use "_" instead